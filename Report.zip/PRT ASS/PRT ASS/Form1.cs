﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRT_ASS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            /* s225250306 Asanda Khathide
             * s225315351 Nkanyiso Madonsela
             * s225082640 Teboho Chukuma
             * s224148524 Morwe Ofense
           */

            head.Text = "COMPANY SALE FOR THE PAST 5 YEARS:" +
                "\n==================================";
            //declaration
            string[] Employee;
            string year, branch;
            double yearAverage = 0, totalCount = 0, BranchAverage = 0, Branchcount = 0, Yearcount = 1, totalAverage = 0, subAverage = 0;

            StreamReader Read = new StreamReader("Assignment2TextFile.txt");//reads from file

            Employee = Read.ReadLine().Split('#');// splits by # 
            year = Employee[0];//stores year first hold variable
            branch = Employee[1];//stores branch second hold variable

        
            MainSection(Employee[0]);//report header
            printBranch(Employee[1]);
            BranchAverage += PrintInfo(Employee[2], Employee[3]);
            Branchcount++;
            totalCount++;

            while (!Read.EndOfStream)
            {
                Employee = Read.ReadLine().Split('#');
                if (year != Employee[0])//year 
                {
                    subAverage += BAverage(BranchAverage, Branchcount);//prints branch average
                    yearAverage = subAverage / Yearcount;
                    totalAverage += yearAverage;
                    YAverage(yearAverage, year);
                    year = Employee[0];//resets branch count
                    Branchcount = 0;//resets branch count
                    BranchAverage = 0;//resets branch count
                    subAverage = 0;//resets branch count
                    yearAverage = 0;//resets branch count
                    Yearcount = 1;//resets branch count
                    totalCount++;
                    branch = Employee[1];//resets branch count
                    MainSection(Employee[0]);//prints main section header
                    printBranch(Employee[1]);//prints subsection header

                }
                else if (branch != Employee[1])
                {

                    subAverage += BAverage(BranchAverage, Branchcount);//prints Branch Average
                    Yearcount++;
                    Branchcount = 0;//resets branch count
                    BranchAverage = 0;//resets branch count
                    branch = Employee[1];//resets branch count
                    printBranch(Employee[1]);//prints subsection header


                }
                Branchcount++;
                BranchAverage += PrintInfo(Employee[2], Employee[3]);

               
            }
            Read.Close();
            subAverage += BAverage(BranchAverage, Branchcount);//prints branch average
            yearAverage = subAverage / Yearcount;
            totalAverage += yearAverage;
            YAverage(yearAverage, year);

            reportFooter(totalAverage, totalCount);


            Console.ReadLine();
        }

        public void MainSection(string year)//mainSubsection  Header
        {
            Display.AppendText("YEAR: " + year + "\n");
        }

        public void printBranch(string branch)//subsection Header
        {
            Display.AppendText("\t" + branch.ToUpper() + "\n");
        }

        public double PrintInfo(string empNumber, string sales)//prints details
        {
            Display.AppendText($"\tEmployee Number {empNumber}:\t{sales}\n");
            return double.Parse(sales);
        }

        public void YAverage(double yearAverage, string year)//prints year average
        {
            Display.AppendText($"Year Average {year}:\t\t\t\t{yearAverage:f}\n\n");
        }

        public double BAverage(double branchAverage, double count)//branch average
        {
            double average = branchAverage / count;
            Display.AppendText($"\tBranch Average: {average:f}\n\n");
            return average;
        }

        public void reportFooter(double totalAverage, double count)//prints reprt foot
        {
            double total = totalAverage / count;
            Display.AppendText($" 5 Year Average:\t\t\t\t\t {total:f} \n");
        }

        private void Exit_Click(object sender, EventArgs e)//close program
        {
            this.Close();
        }
    }
}
