﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Practice_Prt_Duplicate
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int rows,stars;

            Console.Write("How many Stars do you want? ");
            stars = int.Parse(Console.ReadLine());
            Console.Write("How many Rows do you want? ");
            rows = int.Parse(Console.ReadLine());
            Console.Clear();

            int[,] array = new int[rows, stars];

            for (int r= 0; r < array.GetLength(0); r++)
            {
                for (int c = 0; c < array.GetLength(1); c++)
                {
                    
                    for(int k = 0; k <= c; k++)
                    {
                        Console.Write("* ");

                    }
                    Console.WriteLine();

                }
                Console.WriteLine();
            }


            Console.ReadLine();
        }
    }
}
